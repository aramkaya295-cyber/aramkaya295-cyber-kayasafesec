import React, { useMemo, useState } from 'react';
import { X, Printer, Award, Shield, QrCode } from 'lucide-react';
import { Course } from '../types/academy';

interface CertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
  course: Course | null;
}

export const CertificateModal: React.FC<CertificateModalProps> = ({ isOpen, onClose, course }) => {
  const [studentName, setStudentName] = useState('');
  const [showNotice, setShowNotice] = useState(false);
  const issueDate = useMemo(() => new Date().toLocaleDateString('ar', {
    year: 'numeric', month: 'long', day: 'numeric',
  }), []);
  // This is deliberately labelled as a preview ID until a server-side registry exists.
  const previewId = useMemo(() => `KAYA-PREVIEW-${new Date().getFullYear()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`, []);

  if (!isOpen || !course) return null;

  const handlePrint = () => {
    setShowNotice(true);
    window.setTimeout(() => window.print(), 80);
  };

  return (
    <div className="certificate-modal fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/90 backdrop-blur-md">
      <style>{`
        .certificate-sheet { color:#f4f9ff; background:radial-gradient(ellipse at 50% 45%,#102c50 0%,#061329 58%,#020817 100%); border:3px solid #16bfff; box-shadow:inset 0 0 0 7px #061329,inset 0 0 0 9px #0878b5; position:relative; }
        .certificate-sheet:before { content:"";position:absolute;inset:13px;border:1px solid #168ed2;pointer-events:none; }
        .certificate-sheet:after { content:"KAYA SAFE&SEC ACADEMY";position:absolute;left:50%;top:50%;transform:translate(-50%,-50%) rotate(-25deg);font-size:clamp(24px,4vw,56px);font-weight:900;letter-spacing:.12em;color:rgba(67,190,255,.055);white-space:nowrap;pointer-events:none; }
        .certificate-print-hide { }
        @page { size:A4 landscape; margin:8mm; }
        @media print {
          body * { visibility:hidden !important; }
          .certificate-sheet,.certificate-sheet * { visibility:visible !important; }
          .certificate-modal { position:static!important;display:block!important;background:white!important;padding:0!important;overflow:visible!important; }
          .certificate-modal > div { max-width:none!important;width:100%!important;padding:0!important;margin:0!important;border:0!important;background:white!important;box-shadow:none!important;overflow:visible!important;max-height:none!important; }
          .certificate-print-hide { display:none!important; }
          .certificate-sheet { width:100%!important;height:180mm!important;border-radius:0!important;box-shadow:inset 0 0 0 7px #061329,inset 0 0 0 9px #0878b5!important;print-color-adjust:exact;-webkit-print-color-adjust:exact;break-inside:avoid; }
        }
      `}</style>
      <div className="relative w-full max-w-5xl rounded-2xl border border-slate-800 bg-slate-950 p-4 sm:p-6 shadow-2xl space-y-4 max-h-[96vh] overflow-y-auto">
        <div className="certificate-print-hide flex items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-300">
            <Award className="h-4 w-4" />
            <span>KAyA Safe&Sec — CERTIFICATE PREVIEW / معاينة الشهادة</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={handlePrint} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-400 hover:bg-cyan-300 text-slate-950 text-sm font-bold">
              <Printer className="h-4 w-4" /><span>طباعة / حفظ PDF</span>
            </button>
            <button onClick={onClose} aria-label="إغلاق" className="p-2 text-slate-300 hover:text-white rounded-lg hover:bg-slate-900"><X className="h-5 w-5" /></button>
          </div>
        </div>

        <div className="certificate-print-hide flex flex-wrap items-center gap-3 text-sm">
          <label htmlFor="certificate-student-name" className="text-slate-300">اسم المتدرب:</label>
          <input id="certificate-student-name" type="text" value={studentName} onChange={e => setStudentName(e.target.value)}
            placeholder="اكتب الاسم كما سيظهر في المعاينة" className="min-w-56 flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white" />
        </div>

        <article className="certificate-sheet mx-auto w-full aspect-[1.414/1] min-h-[440px] rounded-xl p-5 sm:p-8 md:p-10 overflow-hidden flex flex-col justify-between text-center" dir="rtl">
          <header className="relative z-10 flex items-center justify-between gap-3 border-b border-cyan-500/50 pb-3">
            <div className="text-left text-[9px] sm:text-xs tracking-wider text-cyan-200">
              <div className="font-bold">KAYA-FOUNDATIONS</div><div>LEARN / PRACTICE / PROTECT</div>
            </div>
            <div className="flex items-center gap-2 sm:gap-3">
              <div className="h-10 w-10 sm:h-14 sm:w-14 rounded-full border-2 border-cyan-400 flex items-center justify-center text-cyan-200 font-black text-xs sm:text-base">KAyA</div>
              <div className="text-right"><div className="text-sm sm:text-xl font-black tracking-wide">KAyA SAFE&SEC ACADEMY</div><div className="text-[10px] sm:text-sm text-cyan-300">Cyber Defense & Intelligence Curriculum</div><div className="text-[10px] sm:text-sm text-slate-300">أكاديمية الأمن السيبراني</div></div>
            </div>
            <div className="hidden sm:block text-right text-xs text-cyan-200"><Shield className="inline h-7 w-7 mb-1"/><div>المسار التدريبي</div><div>Training Track</div></div>
          </header>

          <section className="relative z-10 space-y-2 sm:space-y-3 py-2">
            <h1 className="text-2xl sm:text-4xl md:text-5xl font-black leading-tight text-white">شهادة إتمام وتدريب</h1>
            <p className="text-xs sm:text-base text-slate-200">تشهد أكاديمية KAyA Safe&Sec بأن المتدرب/ة:</p>
            <div className="mx-auto w-11/12 border-y-2 border-cyan-400 py-2 sm:py-3 text-xl sm:text-3xl font-black text-cyan-200 min-h-10">
              {studentName.trim() || '................................................'}
            </div>
            <p className="text-xs sm:text-sm text-slate-200">قد أتم متطلبات المسار التدريبي الموضح أدناه وفق سجل الإنجاز المتاح للأكاديمية:</p>
            <div className="mx-auto max-w-3xl border-y border-cyan-400/80 px-3 py-2 sm:py-3">
              <div className="text-lg sm:text-2xl font-black text-cyan-300">{course.title}</div>
              <div className="text-[10px] sm:text-sm text-slate-200 mt-1">Cyber Security Training Track · {course.hours} ساعة تدريبية بحسب بيانات المسار</div>
            </div>
            <p className="text-[10px] sm:text-xs text-slate-300">نتمنى لكم مزيدًا من التقدم والنجاح في مسيرتكم التعليمية والمهنية.</p>
          </section>

          <footer className="relative z-10 grid grid-cols-3 items-end gap-2 sm:gap-5 border-t border-cyan-500/50 pt-3 text-[9px] sm:text-xs">
            <div className="text-right space-y-1">
              <div className="font-bold text-cyan-200">معرّف المعاينة</div>
              <div dir="ltr" className="break-all text-slate-200">{previewId}</div>
              <div className="text-slate-400">التاريخ: {issueDate}</div>
            </div>
            <div className="flex flex-col items-center gap-1 text-cyan-200">
              <div className="rounded-full border-2 border-cyan-400 p-2 sm:p-3"><Shield className="h-7 w-7 sm:h-10 sm:w-10"/></div>
              <div className="font-bold">KAyA Safe&Sec Academy</div>
              <div className="text-slate-400">ختم تصميمي للمعاينة</div>
            </div>
            <div className="text-left space-y-1">
              <div className="font-bold text-cyan-200">المهندس: حسن خلو</div>
              <div className="text-slate-300">المؤسس والمشرف الأكاديمي</div>
              <div className="text-slate-500">Founder & Academic Supervisor</div>
            </div>
          </footer>
          <div className="relative z-10 certificate-print-hide flex items-center justify-center gap-2 border-t border-amber-400/40 pt-2 text-[10px] text-amber-200">
            <QrCode className="h-4 w-4 shrink-0" />
            <span>معاينة تصميمية فقط — التحقق الإلكتروني غير متاح حتى ربط سجل شهادات موثوق. لا تُعد هذه النسخة إثبات اعتماد.</span>
          </div>
        </article>
        {showNotice && <p className="certificate-print-hide text-xs text-amber-300" role="status">تنبيه: المطبوع نموذج معاينة، وليس شهادة اعتماد موثّقة. لم يتم إنشاء سجل رسمي للشهادة.</p>}
      </div>
    </div>
  );
};
