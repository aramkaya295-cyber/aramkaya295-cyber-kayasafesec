import React, { useState } from 'react';
import { Phone, Search, ShieldCheck, Info, ExternalLink } from 'lucide-react';

const PREFIXES: Array<[string, string]> = [
  ['+1', 'الولايات المتحدة / كندا'], ['+20', 'مصر'], ['+27', 'جنوب أفريقيا'], ['+30', 'اليونان'],
  ['+33', 'فرنسا'], ['+34', 'إسبانيا'], ['+39', 'إيطاليا'], ['+44', 'المملكة المتحدة'],
  ['+49', 'ألمانيا'], ['+90', 'تركيا'], ['+91', 'الهند'], ['+961', 'لبنان'], ['+962', 'الأردن'],
  ['+963', 'سوريا'], ['+964', 'العراق'], ['+965', 'الكويت'], ['+966', 'السعودية'], ['+971', 'الإمارات'], ['+974', 'قطر']
];
export const PhoneOwnerLookup: React.FC = () => {
  const [phone, setPhone] = useState('');
  const [result, setResult] = useState<{ normalized: string; country: string; valid: boolean } | null>(null);
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const normalized = phone.trim().replace(/[\s().-]/g, '').replace(/^00/, '+');
    const valid = /^\+?[1-9]\d{6,14}$/.test(normalized);
    const international = normalized.startsWith('+') ? normalized : `+${normalized}`;
    const match = PREFIXES.sort((a, b) => b[0].length - a[0].length).find(([prefix]) => international.startsWith(prefix));
    setResult({ normalized: international, country: match?.[1] ?? 'رمز دولة غير معروف في القائمة المحلية', valid });
  };
  return <div className="space-y-5 animate-in fade-in duration-300">
    <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 space-y-3">
      <div className="flex items-center gap-2 text-emerald-300"><Phone className="h-5 w-5"/><h2 className="text-xl font-bold text-white">تحقق من تنسيق رقم الهاتف</h2></div>
      <p className="text-sm text-slate-300">هذه الأداة تتحقق محلياً من التنسيق الدولي ورمز الدولة فقط. لا تتصل بقواعد بيانات اتصالات ولا تكشف هوية المالك أو بريده أو موقعه.</p>
      <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-2">
        <input value={phone} onChange={e => setPhone(e.target.value)} type="tel" required dir="ltr" placeholder="+44 7700 900123" className="flex-1 rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-white font-mono" />
        <button className="flex items-center justify-center gap-2 rounded-xl bg-emerald-400 px-5 py-3 font-bold text-slate-950"><Search className="h-4 w-4"/>تحقق من الرقم</button>
      </form>
    </section>
    {result && <section className={`rounded-xl border p-5 ${result.valid ? 'border-emerald-500/30 bg-emerald-950/20' : 'border-amber-500/30 bg-amber-950/20'}`}>
      <div className="flex items-center gap-2 font-bold text-white">{result.valid ? <ShieldCheck className="h-5 w-5 text-emerald-400"/> : <Info className="h-5 w-5 text-amber-400"/>}{result.valid ? 'التنسيق يبدو صالحاً مبدئياً' : 'تنسيق غير صالح مبدئياً'}</div>
      <p className="mt-3 text-sm text-slate-200" dir="ltr">{result.normalized}</p><p className="mt-1 text-sm text-slate-300">رمز الدولة: {result.country}</p>
      <p className="mt-3 text-xs text-slate-400">التحقق من التنسيق لا يثبت أن الرقم نشط أو أن رمز الدولة يطابق مكان وجود صاحبه.</p>
      <a className="mt-3 inline-flex items-center gap-1 text-sm text-emerald-300 underline" href="https://www.itu.int/en/ITU-T/inr/Pages/default.aspx" target="_blank" rel="noreferrer">مرجع الترقيم الدولي ITU <ExternalLink className="h-3 w-3"/></a>
    </section>}
  </div>;
};
