import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = Number(process.env.PORT) || 3000;

// Baseline hardening. Configure equivalent controls at the production proxy/CDN too.
app.disable('x-powered-by');
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});
app.use(express.json({ limit: '32kb', strict: true }));

// Lightweight per-process rate limit for the public AI endpoint. Use a shared store
// (e.g. Redis/edge rate limiting) when running multiple production instances.
const aiRequests = new Map<string, { count: number; resetAt: number }>();
const AI_WINDOW_MS = 60_000;
const AI_MAX_REQUESTS = 12;
let aiRateLimitChecks = 0;
function aiRateLimit(req: express.Request, res: express.Response, next: express.NextFunction) {
  const now = Date.now();
  // Periodically remove expired entries so rotating source IPs cannot grow this map forever.
  if (++aiRateLimitChecks % 100 === 0) {
    for (const [ip, entry] of aiRequests) {
      if (entry.resetAt <= now) aiRequests.delete(ip);
    }
  }
  const key = req.ip || req.socket.remoteAddress || 'unknown';
  const entry = aiRequests.get(key);
  if (!entry || entry.resetAt <= now) {
    aiRequests.set(key, { count: 1, resetAt: now + AI_WINDOW_MS });
    return next();
  }
  if (entry.count >= AI_MAX_REQUESTS) {
    res.setHeader('Retry-After', String(Math.ceil((entry.resetAt - now) / 1000)));
    return res.status(429).json({ error: 'تم تجاوز حد الطلبات. حاول مرة أخرى بعد قليل.' });
  }
  entry.count += 1;
  return next();
}

// API route for Educational AI Assistant (KAyA Cyber Mentor)
app.post('/api/ai-mentor', aiRateLimit, async (req, res) => {
  try {
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
    const allowedModes = new Set(['hint', 'error', 'report_review', 'lesson']);
    const mode = typeof body.mode === 'string' && allowedModes.has(body.mode) ? body.mode : 'lesson';
    const context = body.context;
    if (!prompt || prompt.length > 6000) {
      return res.status(400).json({ error: 'يجب أن يكون السؤال بين حرف واحد و6000 حرف.' });
    }
    let safeContext = 'منصة KAyA SafeSec للأمن السيبراني';
    if (context !== undefined) {
      try {
        const serialized = JSON.stringify(context);
        if (serialized.length > 4000) {
          return res.status(400).json({ error: 'السياق المرسل كبير جدًا.' });
        }
        safeContext = serialized;
      } catch {
        return res.status(400).json({ error: 'صيغة السياق غير صالحة.' });
      }
    }
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      // Return null so client falls back gracefully to built-in knowledge engine
      return res.status(200).json({ reply: null });
    }

    const ai = new GoogleGenAI({ apiKey });
    const systemPrompt = `أنت "مرشد كايا السيبراني" (KAyA Cyber Mentor)، مستشار وخبير تعليمي متخصص في الأمن السيبراني والتحقيق الجنائي الرقمي بأكاديمية KAyA SafeSec.
مهمتك:
- الإجابة باللغة العربية الفصحى السليمة والمهنية مع دعم المصطلحات الإنجليزية الفنية الدقيقة.
- نمط الشرح: ${
      mode === 'hint'
        ? 'قدّم تلميحات متدرجة ذكية خطوة بخطوة دون إعطاء الحل المباشر أو كشف الراية مباشرة.'
        : mode === 'error'
        ? 'حلل رسالة الخطأ أو مخرجات الطرفية بدقة واشرح سببها الجذري وكيفية تصحيحها.'
        : mode === 'report_review'
        ? 'راجع مسودة التقرير، تحقق من واقعية المخاطر واقترح تحسينات هندسية واضحة.'
        : 'اشرح المفهوم بأسلوب هندسي تطبيقي يربط بين النظرية والتطبيق في المختبر.'
    }
السياق الحالي: ${safeContext}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [
        { role: 'user', parts: [{ text: `${systemPrompt}\n\nسؤال الطالب: ${prompt}` }] }
      ]
    });

    res.json({ reply: response.text });
  } catch (error) {
    console.error('AI Mentor request failed:', error instanceof Error ? error.message : 'Unknown error');
    res.status(502).json({ reply: null, error: 'تعذر الوصول إلى المرشد الذكي حاليًا.' });
  }
});

async function startServer() {
  app.use(express.static('public'));

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static('dist'));
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${port}`);
  });
}

startServer();
