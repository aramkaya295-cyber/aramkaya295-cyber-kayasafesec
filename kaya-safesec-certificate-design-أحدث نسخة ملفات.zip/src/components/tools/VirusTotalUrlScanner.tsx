import React, { useState } from 'react';
import { AlertTriangle, CheckCircle2, Info, Search, ShieldAlert, ShieldCheck } from 'lucide-react';

type Finding = { title: string; detail: string; severity: 'high' | 'medium' | 'info' };
function inspectUrl(raw: string): { normalized: string; findings: Finding[]; valid: boolean } {
  let parsed: URL;
  try { parsed = new URL(/^https?:\/\//i.test(raw.trim()) ? raw.trim() : `https://${raw.trim()}`); }
  catch { return { normalized: raw, findings: [{ title: 'تنسيق الرابط غير صالح', detail: 'أدخل نطاقاً أو رابطاً صحيحاً مثل https://example.com', severity: 'high' }], valid: false }; }
  const findings: Finding[] = [];
  if (parsed.protocol !== 'https:') findings.push({ title: 'الرابط لا يستخدم HTTPS', detail: 'الاتصال قد لا يكون مشفراً من طرف المستخدم إلى الموقع.', severity: 'medium' });
  if (parsed.username || parsed.password) findings.push({ title: 'بيانات اعتماد داخل الرابط', detail: 'وجود اسم مستخدم أو كلمة مرور ضمن URL قد يؤدي إلى كشفها في السجلات.', severity: 'high' });
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(parsed.hostname)) findings.push({ title: 'استخدام عنوان IP مباشر', detail: 'تحقق من هوية المضيف وشهادة TLS قبل المتابعة.', severity: 'medium' });
  if (parsed.hostname.startsWith('xn--') || parsed.hostname.split('.').some(part => part.startsWith('xn--'))) findings.push({ title: 'نطاق دولي مرمّز (Punycode)', detail: 'تحقق من احتمال تشابه الأحرف مع نطاق معروف.', severity: 'medium' });
  if (parsed.hostname.length > 50 || parsed.href.length > 180) findings.push({ title: 'نطاق أو رابط طويل بشكل غير معتاد', detail: 'الطول وحده لا يثبت الخبث؛ افحص الرابط والسياق بعناية.', severity: 'info' });
  if (/(login|verify|secure|account|wallet|update|password)/i.test(parsed.hostname) && !/^(accounts\.google\.com|login\.microsoftonline\.com|appleid\.apple\.com)$/i.test(parsed.hostname)) findings.push({ title: 'كلمات قد تُستخدم في انتحال صفحات الدخول', detail: 'هذه إشارة سياقية فقط وليست دليلاً قاطعاً على التصيد.', severity: 'info' });
  if (!findings.length) findings.push({ title: 'لم تُرصد مؤشرات ضمن القواعد المحلية', detail: 'هذا لا يعني أن الموقع آمن؛ لم يتم الاتصال بأي مزوّد سمعة أو محرك مكافحة برمجيات خبيثة.', severity: 'info' });
  return { normalized: parsed.href, findings, valid: true };
}
export const VirusTotalUrlScanner: React.FC = () => {
  const [url, setUrl] = useState('');
  const [result, setResult] = useState<ReturnType<typeof inspectUrl> | null>(null);
  return <div className="space-y-5 animate-in fade-in duration-300">
    <section className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 sm:p-6 space-y-4">
      <div className="flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-cyan-300"/><h2 className="text-xl font-bold text-white">فاحص مؤشرات الروابط المحلي</h2></div>
      <p className="text-sm text-slate-300">يفحص الرابط داخل المتصفح بقواعد إرشادية فقط. لا يتصل بـ VirusTotal أو 72 محركاً خارجياً ولا يصدر حكماً مؤكداً على سلامة الموقع.</p>
      <form onSubmit={e => { e.preventDefault(); if (url.trim()) setResult(inspectUrl(url)); }} className="flex flex-col sm:flex-row gap-2">
        <input value={url} onChange={e => setUrl(e.target.value)} required dir="ltr" placeholder="https://example.com" className="flex-1 rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-white font-mono" />
        <button className="flex items-center justify-center gap-2 rounded-xl bg-cyan-400 px-5 py-3 font-bold text-slate-950"><Search className="h-4 w-4"/>تحليل محلي</button>
      </form>
      <div className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-950/20 p-3 text-xs text-amber-200"><Info className="h-4 w-4 shrink-0"/>لا ترسل روابط خاصة تحتوي على رموز دخول أو معلومات شخصية. التحليل المحلي لا يرفع الرابط إلى خادم خارجي.</div>
    </section>
    {result && <section className="rounded-2xl border border-slate-800 bg-slate-950/70 p-5 space-y-4">
      <div className="flex items-center gap-2">{result.valid ? <ShieldAlert className="h-5 w-5 text-amber-300"/> : <AlertTriangle className="h-5 w-5 text-rose-300"/>}<h3 className="font-bold text-white">نتيجة المؤشرات المحلية</h3></div>
      <p className="font-mono text-sm text-slate-300 break-all" dir="ltr">{result.normalized}</p>
      {result.findings.map((f, i) => <div key={`${f.title}-${i}`} className="rounded-xl border border-slate-800 p-4"><div className="flex items-center gap-2 font-semibold text-white">{f.severity === 'high' ? <AlertTriangle className="h-4 w-4 text-rose-400"/> : f.severity === 'medium' ? <AlertTriangle className="h-4 w-4 text-amber-400"/> : <CheckCircle2 className="h-4 w-4 text-cyan-300"/>}{f.title}</div><p className="mt-1 text-sm text-slate-400">{f.detail}</p></div>)}
      <p className="text-xs text-slate-500">هذه الأداة ليست بديلاً عن فحص السمعة لدى مزود موثوق أو مراجعة شهادة الموقع ومصدر الرابط.</p>
    </section>}
  </div>;
};
